// tests/ticketIsolation.test.js
import request from 'supertest';
import app from '../server.js'; // or your Express app instance
import mongoose from 'mongoose';
import Ticket from '../models/Ticket.js';

describe('Tenant Isolation', () => {
  it("should NOT allow Tenant A to see Tenant B's tickets", async () => {
    await Ticket.create({ title: 'Ticket A', customerId: 'tenantA' });
    await Ticket.create({ title: 'Ticket B', customerId: 'tenantB' });

    const tokenA = 'Bearer ' + getTokenForTenant('tenantA');
    const res = await request(app)
      .get('/api/tickets')
      .set('Authorization', tokenA);

    expect(res.body).toEqual(expect.not.arrayContaining([
      expect.objectContaining({ customerId: 'tenantB' })
    ]));
  });
});
