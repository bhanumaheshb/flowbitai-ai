test('Admin from Tenant A cannot read Tenant B data', async () => {
  const res = await request(app)
    .get('/api/data')
    .set('Authorization', `Bearer ${tenantAToken}`);
  
  expect(res.body).not.toContainEqual(expect.objectContaining({
    customerId: 'tenantB'
  }));
});