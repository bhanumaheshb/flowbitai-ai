import mongoose from 'mongoose';

const ticketSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  status: {
    type: String,
    enum: ['open', 'in_progress', 'closed'],
    default: 'open'
  },
  customerId: { type: String, required: true }
}, { timestamps: true });

export default mongoose.model('Ticket', ticketSchema);
