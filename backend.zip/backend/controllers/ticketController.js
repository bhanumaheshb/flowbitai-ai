import Ticket from '../models/Ticket.js';
import axios from 'axios';

const N8N_SECRET = process.env.N8N_SHARED_SECRET;
const N8N_WEBHOOK_URL = process.env.N8N_WEBHOOK_URL || 'http://localhost:5678/webhook/new-ticket';

/**
 
 */
export const createTicket = async (req, res) => {
  const { title, description } = req.body;
  const { customerId } = req.user;

  // Validation
  if (!title || typeof title !== 'string') {
    return res.status(400).json({
      success: false,
      message: 'Valid title is required'
    });
  }

  try {
    // Create ticket
    const ticket = await Ticket.create({
      title,
      description: description || '',
      customerId,
      status: 'open' // Explicitly set initial status
    });

    // Call n8n webhook asynchronously
    try {
      await axios.post(N8N_WEBHOOK_URL, {
        ticketId: ticket._id,
        customerId: ticket.customerId,
        title: ticket.title
      }, {
        headers: {
          'x-n8n-secret': N8N_SECRET
        }
      });
    } catch (webhookError) {
      console.error('n8n webhook failed:', webhookError.message);
      // Continue even if webhook fails
    }

    res.status(201).json({
      success: true,
      ticket
    });

  } catch (err) {
    console.error('Ticket creation error:', err);
    res.status(500).json({
      success: false,
      message: 'Ticket creation failed',
      error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
};

/**
 * Get all tickets for admin dashboard
 */
export const getAllTicketsForAdmin = async (req, res) => {
  try {
    const tickets = await Ticket.find().sort({ createdAt: -1 });
    res.json({ success: true, tickets });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching all tickets' });
  }
};

/**
 * Get paginated tickets for current user
 */
export const getTickets = async (req, res) => {
  const { page = 1, limit = 10 } = req.query;

  try {
    const tickets = await Ticket.find({ customerId: req.user.customerId })
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();

    const count = await Ticket.countDocuments({ customerId: req.user.customerId });

    res.json({
      success: true,
      tickets,
      totalPages: Math.ceil(count / limit),
      currentPage: page
    });

  } catch (err) {
    console.error('Get tickets error:', err);
    res.status(500).json({
      success: false,
      message: 'Error fetching tickets',
      error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
};

/**
 * Get single ticket with validation
 */
export const getTicketById = async (req, res) => {
  try {
    const ticket = await Ticket.findOne({
      _id: req.params.id,
      customerId: req.user.customerId
    });

    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: 'Ticket not found'
      });
    }

    res.json({
      success: true,
      ticket
    });

  } catch (err) {
    console.error('Get ticket error:', err);
    res.status(500).json({
      success: false,
      message: 'Error fetching ticket',
      error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
};

/**
 * Secure webhook for n8n to update ticket status
 */
export const markTicketDone = async (req, res) => {
  const secret = req.headers['x-n8n-secret'];
  const { ticketId } = req.body;

  // Security check
  if (secret !== N8N_SECRET) {
    console.warn('Invalid webhook secret attempt');
    return res.status(403).json({
      success: false,
      message: 'Unauthorized'
    });
  }

  if (!ticketId) {
    return res.status(400).json({
      success: false,
      message: 'Ticket ID is required'
    });
  }

  try {
    const ticket = await Ticket.findByIdAndUpdate(
      ticketId,
      { status: 'closed' },
      { new: true }
    );

    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: 'Ticket not found'
      });
    }

    // Here you would add WebSocket or other real-time update logic

    res.json({
      success: true,
      message: 'Ticket marked as closed',
      ticket
    });

  } catch (err) {
    console.error('Mark ticket done error:', err);
    res.status(500).json({
      success: false,
      message: 'Error updating ticket',
      error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }
};