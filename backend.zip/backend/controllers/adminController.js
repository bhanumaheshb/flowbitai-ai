// backend/controllers/adminController.js

import Ticket from '../models/Ticket.js';

// Admin-only: Get all tickets
export const getAllTickets = async (req, res) => {
  try {
    const tickets = await Ticket.find().populate('createdBy', 'email customerId');
    res.status(200).json({ success: true, tickets });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch tickets',
      error: err.message
    });
  }
};
