// controllers/userController.js

import User from '../models/User.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

// Generate token with role, customerId, and user ID
const generateToken = (user) => {
  return jwt.sign(
    {
      id: user._id,
      customerId: user.customerId,
      role: user.role
    },
    process.env.JWT_SECRET,
    { expiresIn: '30d' }
  );
};

// Register user
export const register = async (req, res) => {
  const { name, email, password, customerId, role = 'user' } = req.body;
  try {
    if (!name || !email || !password || !customerId) {
      return res.status(400).json({ 
        success: false,
        message: 'All fields are required' 
      });
    }

    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(400).json({ 
        success: false,
        message: 'User already exists' 
      });
    }

    const newUser = await User.create({
      name,
      email,
      password,
      customerId,
      role
    });

    res.status(201).json({
      success: true,
      token: generateToken(newUser),
      user: {
        id: newUser._id,
        name: newUser.name,
        role: newUser.role,
        customerId: newUser.customerId
      }
    });
  } catch (err) {
    res.status(500).json({ 
      success: false,
      message: 'Registration failed', 
      error: err.message 
    });
  }
};

// Login user (keep this only!)
export const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email }).select('+password');
    if (!user) {
      console.log("User not found");
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      console.log("Password mismatch");
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    console.log("Login successful:", user.email);

    res.json({
      success: true,
      token: generateToken(user),
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        customerId: user.customerId
      }
    });
  } catch (err) {
    console.error("Login failed:", err);
    res.status(500).json({
      success: false,
      message: 'Login failed',
      error: err.message
    });
  }
};
