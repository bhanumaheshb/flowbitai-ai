import express from 'express';
import {
  createTicket,
  getTickets,
  getTicketById,
  markTicketDone
} from '../controllers/ticketController.js';

import { getAllTickets } from '../controllers/adminController.js';
import { authenticate } from '../middleware/auth.js';
import { protect, isAdmin } from '../middleware/authMiddleware.js';

const router = express.Router();

// Tenant routes
router.post('/', authenticate, createTicket);
router.get('/', authenticate, getTickets);
router.get('/:id', authenticate, getTicketById);
router.post('/webhook/mark-done', markTicketDone);

// Admin-only route
router.get('/admin/tickets', protect, isAdmin, getAllTickets);

export default router;
