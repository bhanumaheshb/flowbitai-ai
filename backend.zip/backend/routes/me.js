import express from 'express';
import { authenticate } from '../middleware/auth.js';
import registry from '../registry.json' assert { type: 'json' };

const router = express.Router();

router.get('/me/screens', authenticate, (req, res) => {
  const screens = registry.tenants[req.user.customerId] || [];
  res.json({ screens });
});

export default router;
