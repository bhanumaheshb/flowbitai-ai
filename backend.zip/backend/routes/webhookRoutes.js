router.post('/webhook/ticket-done', async (req, res) => {
  const secret = req.headers['x-shared-secret'];
  if (secret !== process.env.WEBHOOK_SECRET) {
    return res.status(401).json({ message: 'Invalid webhook secret' });
  }

  const { ticketId, status } = req.body;
  await Ticket.findByIdAndUpdate(ticketId, { status });

  res.status(200).json({ message: 'Ticket updated' });
});
